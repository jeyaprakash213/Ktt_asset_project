const mongoose = require('mongoose');
const Schema = mongoose.Schema;
mongoose.set('strictQuery', true);


const EmployeeSchema = new Schema({
    EmployeeName: { type: String, required: true },
    EmployeeEmail: { type: String, required: true },
    EmployeePhone: { type: String, required: true },
    selectedStatus: { type: String, enum: ['active', 'inactive'], default: 'active' },
    createdAt: { type: Date, default: Date.now }


});

const AssetSchema = new mongoose.Schema({
    assetId: { type: String, unique: true }, // Internal tracking ID
    serialNumber: { type: String, required: true }, // Manufacturer serial
    make: { type: String, required: true },
    model: { type: String, required: true },
    value: { type: Number, required: true },
    branch: { type: String },
    status: {
        type: String,
        enum: ['in_stock', 'issued', 'returned', 'scrapped', 'sold'],
        default: 'in_stock'
    },
    category: { type: String, ref: 'AssetCategory', default: null },
    holder: { type: String, ref: 'Employee', default: null },
    createdAt: { type: Date, default: Date.now }
});


const TransactionSchema = new mongoose.Schema({
    serialNumber: { type: String, ref: 'Asset' },
    employee: { type: String, ref: 'Employee' },
    action: {
        type: String,
        enum: ['sold', 'issued', 'returned', 'scrapped'],
        required: true
    },
    reason: String, // optional for 'return'
    date: { type: Date, default: Date.now }
});

const Asset = mongoose.model('Asset', AssetSchema);

const Employee = mongoose.model('Employee', EmployeeSchema);
const Transaction = mongoose.model('Transaction', TransactionSchema);
module.exports = { Employee, Asset, Transaction };
