#project setup 


PreRequistics
-------------

* git
* node
* npm
* angular-cli


git setup
---------

try these commands to set user account
```
git config --global user.name "yourname"
git config --global user.email "yourmail"
```

git clone
---------
clone development branch. use same username and passowrd that is used in gitlab

```angular2html
git clone http://192.168.1.15/deliboy/deliboyapp.git -b Development
```

Dependencies:
------------

install dependencies and check for latest

```angular2html
npm install
npm update
```


Run angular-cli
--------------
everytime you got git update. try running app and check if anything breaking

```angular2html
ng serve
```


git practice
------------
* always work with latest code atleast once in day update your project
* push code regularly keep you version clean
* before commit & push pull from remote
* if there is merge conflict resolve it manually
* every commit should have proper comment
* check success notification for all git actions
