#/bin/bash
#upload files
export AWS_ACCESS_KEY_ID=AKIAVOW3QPF3FQUKRK5U
export AWS_SECRET_ACCESS_KEY=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
aws s3 cp ./dist s3://apps-deliforce.io --recursive --acl public-read

#https://console.aws.amazon.com/s3/#
