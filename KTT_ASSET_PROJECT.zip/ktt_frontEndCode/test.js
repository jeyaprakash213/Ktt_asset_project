exports.handleHttpRequests = (url) => {
  return new Promise((resolve, reject) => {
    const request = http.request(url, res => {
      let chunks = [];
      res.on('data', chunk => {
        chunks.push(chunk);
      });

      res.on('end', () => {
        let body = Buffer.concat(chunks).toString();
        resolve(body);
      })

    });
    request.on('error', (e) => {
      reject('problem with request: ' + e.message);
    });
    request.end();
  }).then(data => {
    return data;
  });
};
