import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
// export class AppComponent {
//   title = 'my-app';
// }
export class AppComponent implements OnInit {
  EmployeeDatas: any[] = [];
  EmployeeName: any;
  EmployeeEmail: any;
  EmployeePhone: any;
  selectedStatus: any;




  constructor(private http: HttpClient) {
    this.getEmployee()
  }
  ngOnInit(): void {

    // this.getEmployee()
  }



  addEmployee() {
    console.log(JSON.stringify(this.selectedStatus))
    let bodyData = {
      "EmployeeName": this.EmployeeName,
      "EmployeeEmail": this.EmployeeEmail,
      "EmployeePhone": this.EmployeePhone,
      "selectedStatus": "active"
    };

    console.log("bodyData", bodyData)

    this.http.post("http://localhost:3000/Employeeregister", bodyData).subscribe((resultData: any) => {
      console.log("resultData", resultData);

      // this.ProductArray.push(resultData.Products)
      // console.log("ProductArray", this.ProductArray);
      alert("Product add Successfully")
      // this.getAllProducts();
      this.EmployeeName = '';
      this.EmployeeEmail = '';
      this.EmployeePhone = '';
      this.selectedStatus = '';

      // this.getAllpurchaseProducts()

    });







  }


  getEmployee() {
    console.log("jjjjjjjjjjj")
    this.http.get("http://localhost:3000/searchEmployee")
      .subscribe((resultData: any) => {
        console.log("resultData", resultData);
        this.EmployeeDatas = resultData.data;
        console.log("this.EmployeeDatas", this.EmployeeDatas);
        // this.selectedProduct = resultData.Products.productName
      });
  }


}