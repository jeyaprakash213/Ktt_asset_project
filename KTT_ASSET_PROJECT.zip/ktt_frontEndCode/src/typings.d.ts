/* SystemJS module definition */
declare var module: NodeModule;
declare var Applozic: any;
declare var jqueryDataTables: any;
declare var dataTablesResponsive: any;
declare var dataTablesBootstrap: any;
declare var dataTablesSelect: any;
declare var modalEffects: any;
declare var modernizr: any;
declare var select2: any;
declare var classie: any;

interface NodeModule {
  id: string;
}
