export const environment = {
  production: true,
  region: 'ap-south-1',
  identityPoolId: '',
  userPoolId: 'ap-south-1_zNMeUGg0o',
  clientId: '56ugitb9ooie3erkno85d1877b',
  ddbTableName: 'LoginTrail',
  cognito_idp_endpoint: '',
  cognito_identity_endpoint: '',
  sts_endpoint: '',
  dynamodb_endpoint: '',
  s3_endpoint: '',
  endpoint: 'a3uio9gq5u1i5e-ats.iot.ap-south-1.amazonaws.com',
  accessKeyId: 'AKIAJ2636I4HJO2LP6AA',
  secretAccessKey: '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'
};
