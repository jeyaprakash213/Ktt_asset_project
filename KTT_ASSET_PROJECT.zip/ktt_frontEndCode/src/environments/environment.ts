
// export const environment = { // Dev cred
//   production: true,
//   region: 'ap-south-1',
//   identityPoolId: '',
//   userPoolId: 'ap-south-1_Z8zoPzlMl',
//   clientId: '35p74rrhf6sqj0373b5kgmr4re',
//   customUserPoolId: 'ap-south-1_wU9b9B4OZ',
//   customClientId: '5v6aotjck8cd8gsivatc58lpr1',
//   ddbTableName: 'LoginTrail',
//   ksId: 'uKoVYDrlD5mhrNI8djC/dwgJgn0wA+KguiY4gMMy',
//   cognito_idp_endpoint: '',
//   cognito_identity_endpoint: '',
//   sts_endpoint: '',
//   kaId: 'AKIAVOW3QPF3FQUKRK5U',
//   dynamodb_endpoint: '',
//   s3_endpoint: '',
//   bckt: 'trackingpage2',
//   endpoint: 'a2vbld3tfa7lw0-ats.iot.ap-south-1.amazonaws.com',
// };


export const environment = { // Live cred
  production: true,
  region: 'ap-south-1',
  identityPoolId: '',
  userPoolId: 'ap-south-1_zNMeUGg0o',
  clientId: '56ugitb9ooie3erkno85d1877b',
  xquaraUserPoolId: "ap-south-1_xR0OTu5gH",
  xquaraClientId: "4ha4f7bk8i00d6jomh25jr48g7",
  ddbTableName: 'LoginTrail',
  cognito_idp_endpoint: '',
  cognito_identity_endpoint: '',
  sts_endpoint: '',
  dynamodb_endpoint: '',
  s3_endpoint: '',
  endpoint: 'a3uio9gq5u1i5e-ats.iot.ap-south-1.amazonaws.com',
  bckt: 'trackingpage',
  kaId: 'AKIAS6756IL2GLWM63FL',
  ksId: 'hnGSf8lL5FQWpQg++BV4cTAGekRThVw6XOjEGlqU'
};
